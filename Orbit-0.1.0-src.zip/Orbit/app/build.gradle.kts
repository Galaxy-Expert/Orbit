plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.orbit.island"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.orbit.island"
        minSdk = 34
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Xposed API'si Vector/LSPosed tarafından çalışma zamanında sağlanır, APK'ya girmez.
    compileOnly(project(":xposed-api"))
}
